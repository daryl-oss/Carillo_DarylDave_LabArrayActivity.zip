/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package max.min;

import java.util.Scanner;

/**
 * Name: Carillo, DarylDave
 * Section: Computer Engineering - 1st year
 * Lab Activity: Maximum and Minimum Finder - Problem 2
 * Submission Date: October 29,2024
 */
public class Carillo_DarylDave_MaximumAndMinimumFinder_Problem2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[15]; // Array to hold 15 integers

        // Prompt the user to input 15 numbers
        System.out.println("Please enter 15 integers:");

        for (int i = 0; i < 15; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt(); // Read input into the array
        }

        // Initialize max and min with the first element
        int max = numbers[0];
        int min = numbers[0];

        // Find the maximum and minimum elements
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > max) {
                max = numbers[i]; // Update max if the current number is greater
            }
            if (numbers[i] < min) {
                min = numbers[i]; // Update min if the current number is smaller
            }
        }

        // Print the maximum and minimum elements
        System.out.println("Maximum: " + max);
        System.out.println("Minimum: " + min);

        // Close the scanner to prevent resource leaks
        scanner.close();
    }
}

/*
 * Sample Input:
 * 10
 * 20
 * 30
 * 5
 * 50
 * 60
 * 70
 * 80
 * 90
 * 100
 * 15
 * 25
 * 35
 * 45
 * 55
 *
 * Sample Output:
 * Maximum: 100
 * Minimum: 5
 */