/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkgfloat.num;

import java.util.Scanner;

/**
 * Name: Carillo, DarylDave
 * Section: Computer Engineering - 1st year
 * Lab Activity: Reverse an Array - Problem 3
 * Submission Date: October 29,2024
 */
public class Carillo_DarylDave_ReverseAnArray_Problem3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        float[] numbers = new float[5]; // Array to hold 5 floating-point numbers

        // Prompt the user to input 5 floating-point numbers
        System.out.println("Please enter 5 floating-point numbers:");

        for (int i = 0; i < 5; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            numbers[i] = scanner.nextFloat(); // Read input into the array
        }

        // Print the array in reverse order
        System.out.println("Numbers in reverse order:");
        for (int i = 4; i >= 0; i--) {
            System.out.println(numbers[i]); // Print each number in reverse
        }

        // Close the scanner to prevent resource leaks
        scanner.close();
    }
}

/*
 * Sample Input:
 * 1.1
 * 2.2
 * 3.3
 * 4.4
 * 5.5
 * 
 * Sample Output:
 * Numbers in reverse order:
 * 5.5
 * 4.4
 * 3.3
 * 2.2
 * 1.1
 */