/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package frequency;

import java.util.Scanner;

/**
 * Name: Carillo, DarylDave
 * Section: Computer Engineering - 1st year
 * Lab Activity: Frequency Counter - Problem 4
 * Submission Date: October 29,2024
 */
public class Carillo_DarylDave_FrequencyCounter_Problem4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[10]; // Array to hold 10 integers

        // Prompt the user to input 10 integers between 1 and 100
        System.out.println("Please enter 10 integers between 1 and 100:");

        for (int i = 0; i < 10; i++) {
            while (true) {
                System.out.print("Number " + (i + 1) + ": ");
                int input = scanner.nextInt();
                if (input >= 1 && input <= 100) {
                    numbers[i] = input; // Store valid input in the array
                    break; // Valid input, exit the loop
                } else {
                    System.out.println("Please enter a number between 1 and 100.");
                }
            }
        }

        // Prompt the user for the number to check
        System.out.print("Enter a number to check its occurrences: ");
        int numberToCheck = scanner.nextInt();

        // Count how many times the number appears in the array
        int count = 0;
        for (int num : numbers) {
            if (num == numberToCheck) {
                count++; // Increment count for each occurrence
            }
        }

        // Print the result
        System.out.println("The number " + numberToCheck + " appears " + count + " time(s) in the array.");

        // Close the scanner to prevent resource leaks
        scanner.close();
    }
}

/*
 * Sample Input:
 * 10
 * 20
 * 30
 * 20
 * 50
 * 60
 * 20
 * 80
 * 90
 * 100
 * Enter a number to check its occurrences: 20
 * 
 * Sample Output:
 * The number 20 appears 3 time(s) in the array.
 */