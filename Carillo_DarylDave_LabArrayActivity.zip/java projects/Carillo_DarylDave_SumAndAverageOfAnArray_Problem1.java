/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sum.and.ave;

import java.util.Scanner;

/**
 * Name: Carillo, DarylDave
 * Section: Computer Engineering - 1st year
 * Lab Activity: Sum and Average of an Array - Problem 1
 * Submission Date: October 29,2024
 */
public class Carillo_DarylDave_SumAndAverageOfAnArray_Problem1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[10]; 
        int sum = 0; 

        // Prompt the user to input 10 integers
        System.out.println("Please enter 10 integers:");

        for (int i = 0; i < 10; i++) {
            System.out.print("Number " + (i + 1) + ": "); 
            numbers[i] = scanner.nextInt(); 
            sum += numbers[i]; // Accumulate sum
        }

        // Calculate average
        double average = sum / 10.0; // Use 10.0 to ensure double division

        // Print the sum and average
        System.out.println("Sum: " + sum);
        System.out.printf("Average: %.2f%n", average); // Print average formatted to 2 decimal places

        // Close the scanner to prevent resource leaks
        scanner.close();
    }
}

/*
 * Sample Input:
 * 10
 * 20
 * 30
 * 40
 * 50
 * 60
 * 70
 * 80
 * 90
 * 100
 * 
 * Sample Output:
 * Sum: 550
 * Average: 55.00
 */